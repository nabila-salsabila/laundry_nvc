<?php

namespace App\Models;

use App\Core\Model;

class Paket extends Model
{

     public function show()
     {
          $query = "SELECT * FROM tb_laundry";
          $stmt = $this->db->prepare($query);
          $stmt->execute();

          return $this->selects($stmt);
     }

     public function save()
     {
          $pak_nama = $_POST['laun_nama'];
          $laun_harga = $_POST['laun_harga'];

          $sql = "INSERT INTO tb_launet SET laun_nama=:laun_nama, laun_harga=:laun_harga";
          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":laun_nama", $laun_nama);
          $stmt->bindParam(":laun_harga", $laun_harga);

          $stmt->execute();
     }

     public function edit($id)
     {
          $query = "SELECT * FROM tb_launet WHERE laun_id=:laun_id";
          $stmt = $this->db->prepare($query);

          $stmt->bindParam(":laun_id", $id);
          $stmt->execute();

          return $this->select($stmt);
     }

     public function update()
     {
          $laun_nama = $_POST['laun_nama'];
          $laun_harga = $_POST['laun_harga'];
          $id = $_POST['id'];

          $sql = "UPDATE tb_launet
          SET laun_nama=:laun_nama, laun_harga=:laun_harga WHERE laun_id=:laun_id";

          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":laun_nama", $laun_nama);
          $stmt->bindParam(":laun_harga", $laun_harga);
          $stmt->bindParam(":laun_id", $id);

          $stmt->execute();
     }

     public function delete($id)
      {
            $sql = "DELETE FROM tb_laundry WHERE laun_id=:laun_id";
            $stmt = $this->db->prepare($sql);

            $stmt->bindParam(":laun_id", $id);
            $stmt->execute();
      }
}

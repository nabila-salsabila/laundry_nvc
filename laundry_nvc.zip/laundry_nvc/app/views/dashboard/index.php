<h2>Dashboard</h2>

<div class="info">Selamat Datang Di Laundry <b>Nabila Salsabila</b></div>
<div class="info">Ayo Buruan Cuci pakaian anda di sini, Dapatkan Diskon Dan Potongan Hrga Yang Fantastic,
            <p>Di Laundry Ini Akan Membuat Kamu Tidak Kecewa Dan Akan Mendapatkan Keuntungan yang Cukup Banyak </p>
</div>
<div class="info"><b>Pelanggan Setia Pada laundry Kami akan Mendapatkan Diskon Dan Potongan Harga Yang Fantastic:</b>
    <p>- asaa ID:01</p>
    <p>- acaww ID:02</p>
    <p>- lilaww ID:03</p>
    <p>- sayaaww ID:04</p>
    <p>- ulalaw ID:05</p>
</div>